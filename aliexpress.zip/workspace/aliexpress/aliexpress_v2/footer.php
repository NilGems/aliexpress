</main>

<div class="fixed-items-all vartical1-off hidden visible-lg">
    <div class="digkiop-uio">
        <div class="vartical1">
            <a class="item facebook" href="#"><i class="ti-facebook icon"></i></a>
            <div class="item barcode">
                <i class="ti-truck icon"></i>
                <div class="item-hover-contents">Enjoy Convenient Tracking</div>
            </div>
            <a href="#" class="item write-to-us">
                <i class="ti-pencil"></i>
                <div class="item-hover-contents">Write to us</div>
            </a>
        </div>
        <div class="vartical2">
            <button class="item circled toggle-vartical1-on"><i class="ti-close icon"></i></button>
            <button class="item circled toggle-vartical1-off"><i class="ti-plus icon"></i></button>
            <button class="item circled scrollController"><i class="ti-angle-up icon"></i></button>
        </div>
    </div>
</div>

<!---RECENTLY VIEW START---->
<div class="modal fade" id="recently-view-page-main-modal" tabindex="-1" role="dialog" aria-labelledby="recently-view-page-main">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Signin</h4>
            </div>
            <div class="modal-body">
                <div class="col-md-8 col-md-offset-2">
                    <form>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Account :</label>
                            <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Password :</label>
                            <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                        </div>
                        <button class="btn btn-link btn-block">Forgot password ?</button>
                        <button type="submit" class="btn btn-warning btn-block">Submit</button>
                    </form>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="modal-footer">
                <div class="pull-left">
                    Signin with 
                    <div class="btn-group btn-group-sm">
                        <a href="#" class="btn btn-default"><i class="ti-facebook"></i></a>
                        <a href="#" class="btn btn-default"><i class="ti-twitter"></i></a>
                        <a href="#" class="btn btn-default"><i class="ti-google"></i></a>
                    </div>
                </div>
                <div class="pull-right"><a href="#">Join free now!</a></div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<div class="recently-view-float-box hidden visible-lg" id="recently-view-page-main" data-toggle="modal" data-target="#recently-view-page-main-modal">Recently Viewed <i class="ti-angle-double-up"></i></div>
<!---RECENTLY VIEW END---->

<footer>
    <div class="footer">
        <div class="container">
            <?php include(dirname(__FILE__) . '/inc/footer_section1.php'); ?> 
            <?php include(dirname(__FILE__) . '/inc/footer_section2.php'); ?> 
        </div>
    </div>
    <div class="footer-end">
        <div class="container">
            <?php include(dirname(__FILE__) . '/inc/footer_section3.php'); ?> 
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container">
            <?php include(dirname(__FILE__).'/inc/footer_section4.php');?>
        </div>
    </div>
</footer>
</body>
</html>