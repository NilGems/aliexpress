<div class="footer-section1">
    <div class="row">
        <div class="col-md-2 mri-zero-padding-left-right text-center">
            <span><i class="glyphicon glyphicon-piggy-bank"></i></span>
            <div class="heading">Great Value</div>
            <div class="description">
                We offer competitive prices on our 100 million plus product range.
            </div>
        </div>
        <div class="col-md-2 mri-zero-padding-left-right text-center">
            <span><i class="glyphicon glyphicon-plane"></i></span>
            <div class="heading">Worldwide Delivery</div>
            <div class="description">
                With sites in 5 languages, we ship to over 200 countries & regions.
            </div>
        </div>
        <div class="col-md-2 mri-zero-padding-left-right text-center">
            <span><i class="glyphicon glyphicon-credit-card"></i></span>
            <div class="heading">Safe Payment</div>
            <div class="description">
                Pay with the world’s most popular and secure payment methods.
            </div>
        </div>
        <div class="col-md-2 mri-zero-padding-left-right text-center">
            <span class="text-center"><i class="ti-shield"></i></span>
            <div class="heading">Shop with Confidence</div>
            <div class="description">
                Our Buyer Protection covers your purchase from click to delivery.
            </div>
        </div>
        <div class="col-md-2 mri-zero-padding-left-right text-center">
            <span class="text-center"><i class="glyphicon glyphicon-headphones"></i></span>
            <div class="heading">24/7 Help Center</div>
            <div class="description">
                Round-the-clock assistance for a smooth shopping experience.
            </div>
        </div>
        <div class="col-md-2 mri-zero-padding-left-right text-center">
            <span><i class="ti-apple"></i><i class="ti-android"></i></span>
            <div class="heading">Shop On-The-Go</div>
            <div class="description">
                <a href="#">Download the app</a> and get the world of AliExpress at your fingertips.
            </div>
        </div>
    </div>
</div>