<div class="footer-section2">
    <div class="row">
        <div class="col-md-4">
            <h3 class="heading">Subscription</h3>
            <div class="input-group">
                <input type='text' class="form-control" placeholder='Please enter your email'/>
                <span class="input-group-btn">
                    <button class="btn btn-warning">Subscribe</button>
                </span>
            </div>
            <small>Register now to get updates on promotions and coupons.</small>
            <h3 class="heading">Stay connected</h3>
            <div class="btn-group" role="group" aria-label="...">
                <a role="button" class="btn btn-default" href=""><i class="ti-facebook"></i></a>
                <a role="button" class="btn btn-default" href=""><i class="ti-twitter"></i></a>
                <a role="button" class="btn btn-default" href=""><i class="ti-google"></i></a>
            </div>
        </div>
        <div class="col-md-8 mri-zero-padding-left-right">
            <div class="col-md-4">
                <h4 class="heading">How to Buy</h4>
                <ul class="list-unstyled">
                    <li><a href="#" class="item">Making Payments</a></li>
                    <li><a href="#" class="item">Delivery Options</a></li>
                    <li><a href="#" class="item">Buyer Protection</a></li>
                    <li><a href="#" class="item">New User Guide</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h4 class="heading">Customer Service</h4>
                <ul class="list-unstyled">
                    <li><a href="#" class="item">Customer service</a></li>
                    <li><a href="#" class="item">Transaction service agreement</a></li>
                    <li><a href="#" class="item">Take ou r survey</a></li>
                    <li><a href="#" class="item">Organization &amp; Technical support</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h4 class="heading">Partner promotion</h4>
                <ul class="list-unstyled">
                    <li><a href="#" class="item">Partnerships</a></li>
                    <li><a href="#" class="item">Affiliate program</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>