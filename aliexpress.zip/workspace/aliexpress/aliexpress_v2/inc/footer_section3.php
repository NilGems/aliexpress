<div class="footer-section3">
    <div class="row">
        <div class="col-md-6">
            <h3 class="footer-help-heading header">Help</h3>
            <ul class="list-inline">
                <li><a href="#" class="item">Customer Service</a></li>,
                <li><a href="#" class="item">Disputes &amp; Reports</a></li>,
                <li><a href="#" class="item">Making Payment</a></li>,
                <li><a href="#" class="item">Delivery Options</a></li>,
                <li><a href="#" class="item">Buyer Protection</a></li>,
                <li><a href="#" class="item">New User Guide</a></li>
            </ul>
            <h3 class="footer-help-heading header">Browse by Category</h3>
            <ul class="list-inline">
                <li><a href="#" class="item">All Popular</a></li>,
                <li><a href="#" class="item">Product</a></li>,
                <li><a href="#" class="item"> Promotion</a></li>,
                <li><a href="#" class="item">Low Price</a></li>,
                <li><a href="#" class="item">Great Value,</a></li>,
                <li><a href="#" class="item"> Retail</a></li>,
                <li><a href="#" class="item"> Reviews</a></li>,
                <li><a href="#" class="item">China Brands</a></li>
            </ul>
        </div>
        <div class="col-md-6">
            <h3 class="footer-help-heading header">AliExpress Multi-Language Sites</h3>
            <ul class="list-inline">
                <li><a href="#" class="item">Russian</a></li>,
                <li><a href="#" class="item">Portuguese</a></li>,
                <li><a href="#" class="item"> Spanish</a></li>,
                <li><a href="#" class="item">French</a></li>,
                <li><a href="#" class="item">German</a></li>,
                <li><a href="#" class="item">Italian</a></li>,
                <li><a href="#" class="item">Dutch</a></li>,
                <li><a href="#" class="item">Turkish</a></li>,
                <li><a href="#" class="item">Japanese</a></li>,
                <li><a href="#" class="item">Korean</a></li>,
                <li><a href="#" class="item">Thai</a></li>,
                <li><a href="#" class="item">Vietnamese</a></li>,
                <li><a href="#" class="item">Arabic</a></li>,
                <li><a href="#" class="item">Hebrew</a></li>,
                <li><a href="#" class="item">Polish</a></li>
            </ul>
            <h3 class="footer-help-heading header">Alibaba Group</h3>
            <ul class="list-inline">
                <li><a href="#" class="item">Russian</a></li>,
                <li><a href="#" class="item">Portuguese</a></li>,
                <li><a href="#" class="item"> Spanish</a></li>,
                <li><a href="#" class="item">French</a></li>,
                <li><a href="#" class="item">German</a></li>,
                <li><a href="#" class="item">Italian</a></li>,
                <li><a href="#" class="item">Dutch</a></li>,
                <li><a href="#" class="item">Turkish</a></li>,
                <li><a href="#" class="item">Japanese</a></li>,
                <li><a href="#" class="item">Korean</a></li>,
                <li><a href="#" class="item">Thai</a></li>,
                <li><a href="#" class="item">Vietnamese</a></li>,
                <li><a href="#" class="item">Arabic</a></li>,
                <li><a href="#" class="item">Hebrew</a></li>,
                <li><a href="#" class="item">Polish</a></li>
            </ul>
        </div>
        <div class="col-md-12">
            <button class="btn btn-mini btn-primary"><i class="ti-android"></i> Google Play</button>
            <button class="btn btn-mini btn-default"><i class="ti-apple"></i> App Store</button>
        </div>
    </div>
</div>