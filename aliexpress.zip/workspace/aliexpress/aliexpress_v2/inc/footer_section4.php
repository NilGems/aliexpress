<div class="footer-copyright-ctns">
    © 2010-2016 AliExpress.com. All rights reserved.
    <a href="//smritiinfotech.com" target="_blank" class="crator-tag">Design By : <span class="our-logo">Smriti-Infotech</span></a>
</div>