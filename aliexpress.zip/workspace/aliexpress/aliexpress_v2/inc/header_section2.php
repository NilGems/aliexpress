<div class="navigation-bar">
    <div class="header-waper container">
        <div class="">
            <div class="site-logo col-lg-2 col-md-3 col-sm-12 col-xs-12 mri-zero-padding-left-right">
                <div class="mobile-option-comming">
                    <i class="ti-layout-grid3-alt"></i>
                </div>
                <a href="#">
                    <span class="logo">AliExpress</span>
                    <span class="site-tagline">Smart shopping, Better living!</span>
                </a>
            </div>
            <div class="search-box col-lg-6 col-md-4 col-sm-12 col-xs-12 mri-zero-padding-left-right">
                <div class="search-box-warp">
                    <div class="searchbox-width">
                        <div class="autocontrol">
                            <input data-ng-focus="searchengine_on()" data-ng-blur="searchengine_off()" data-ng-model="search.searchinput" type="text" placeholder="Search anything" />
                        </div>
                        <span class="cate-selector">
                            <select class="ui dropdown">
                                <option ng-value="option.value" ng-repeat="option in searchbarcats">
                                    {{option.name}}</option>
                            </select>
                        </span>
                        <div class="btn-c"><button><i class="glyphicon glyphicon-search"></i></button></div>
                    </div>
                    <div class="search-results">
                        <div class="search-hot-deals ng-hide" data-ng-show="!search.searchinput">
                            <sapn>hot search!</sapn>
                            <div>
                                <a href="#">.com</a>
                                <a href="#">.com</a>
                                <a href="#">.com</a>
                                <a href="#">.com</a>
                                <a href="#">.com</a>
                            </div>
                        </div>
                        <div class="ui list">
                            <div class="item">Apples</div>
                            <div class="item">Pears</div>
                            <div class="item">Oranges</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="right-menu col-lg-4 col-md-5 col-sm-12 col-xs-12 mri-zero-padding-left-right">
                <div class="right menu">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 text-center">
                        <a class="item" href="#">
                            <span class="icon-warp"><i class="ti-shopping-cart"></i></span>
                            <span class="text-warp">
                                <span class="upper bugde">0</span>
                                <span class="loweer">Cart</span>
                            </span> 
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-4 hidden-sm hidden-xs text-center">
                        <a class="item" href="#">
                            <span class="icon-warp"><i class="ti-heart"></i></span>
                            <span class="text-warp">
                                <span class="upper">Wish</span>
                                <span class="loweer">List</span>
                            </span>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 text-center"> 
                        <div class="item signin-option ">
                            <span class="icon-warp"><i class="ti-user"></i></span>
                            <span class="text-warp">
                                <span class="upper"><a href="#">Signin</a>|<a href="#">Join</a></span>
                                <span class="loweer">My Aliexpress</span>
                            </span>
                            <div class="hover-effect-section">
                                <p>
                                <h5 class="">Welcome to AliExpress.com</h5>
                                <a href="#" class="btn btn-danger btn-large btn-block">Sign in</a>
                                </p>
                                <div>
                                    Signin with:
                                    <div class="btn-group btn-group-sm">
                                        <a href="#" class="btn btn-default"><i class="ti-facebook"></i></a>
                                        <a href="#" class="btn btn-default"><i class="ti-twitter"></i></a>
                                        <a href="#" class="btn btn-default"><i class="ti-google"></i></a>
                                    </div>
                                </div>
                                <p>
                                <h5 class="">New customer</h5>
                                <a href="#" class="btn btn-warning btn-large btn-block">Join Free</a>
                                </p>
                                <div class="list-group">
                                    <a href="#" class="list-group-item">My AliExpress</a>
                                    <a href="#" class="list-group-item">My Orders</a>
                                    <a href="#" class="list-group-item">Message Center</a>
                                    <a href="#" class="list-group-item">Wishlist</a></li>
                                    <a href="#" class="list-group-item">My Favorite Stores</a>
                                    <a href="#" class="list-group-item">My Coupons</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>