<div class="subheader hidden-md hidden-sm hidden-xs">
    <div class="container">

        <div class="col-md-3 mri-zero-padding-left-right">
            <div class="menu categories">
                <div class="item">CATEGORIES &nbsp;&nbsp;<a href="#">See all <i class="ti-angle-right"></i></a></div>
            </div>
        </div>
        <div class="col-md-9 mri-zero-padding-left-right">
            <div class="menu">
                <a href="#" class="item">SuperDeals</a>
                <a href="#" class="item">Feature Brands</a>
                <a href="#" class="item">Best Selling</a>
                <a href="#" class="item">Tech Discovery</a>
                <a href="#" class="item">Trending Styles</a>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>