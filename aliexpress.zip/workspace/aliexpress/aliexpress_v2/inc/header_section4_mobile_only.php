<div class="mobile-site-navigation-bar">
    <div class="containts">
        <div class="heading-mob">
            <a href=""><img src="image/site-logo.png"/></a>
            <div class="_close"><button><i class="ti-close"></i></button></div>
        </div>
        <div class="section">
            <ul class="list-unstyled">
                <li><a href="#" class="item"><i class="sprite dress"></i>&nbsp;&nbsp;Women's clothing</a></li>
                <li><a href="#" class="item"><i class="sprite shirt"></i>&nbsp;&nbsp;Men's clothing</a></li>
                <li><a href="#" class="item"><i class="sprite smartphone"></i>&nbsp;&nbsp;Phone &amp; Asseccories</a></li>
                <li><a href="#" class="item"><i class="sprite monitor"></i>&nbsp;&nbsp;Computer &amp; Office</a></li>
                <li><a href="#" class="item"><i class="sprite headphones"></i>&nbsp;&nbsp;Consumer Electronics</a></li>
                <li><a href="#" class="item"><i class="sprite diamond"></i>&nbsp;&nbsp;Jewelry &amp; Watches</a></li>
                <li><a href="#" class="item"><i class="sprite armchair"></i>&nbsp;&nbsp;Home, Garden &amp; Furniture</a></li>
                <li><a href="#" class="item"><i class="sprite bag"></i>&nbsp;&nbsp;Bags &amp; Shoes</a></li>
                <li><a href="#" class="item"><i class="sprite pacifier"></i>&nbsp;&nbsp;Toys, Kids &amp; Baby</a></li>
                <li><a href="#" class="item"><i class="sprite ball"></i>&nbsp;&nbsp;Sports &amp; Outdoor</a></li>
                <li><a href="#" class="item"><i class="sprite lipstick"></i>&nbsp;&nbsp;Health &amp; Beauty</a></li>
                <li><a href="#" class="item"><i class="sprite car"></i>&nbsp;&nbsp;Automobiles &amp; Motorcycles</a></li>
                <li><a href="#" class="item"><i class="sprite jackhammer"></i>&nbsp;&nbsp;Home Improvement</a></li>
            </ul>
        </div>
        <div class="section">
            <ul class="list-unstyled">
                <li><a href="#" class="item">SuperDeals</a></li>
                <li><a href="#" class="item">Feature Brands</a></li>
                <li><a href="#" class="item">Best Selling</a></li>
                <li><a href="#" class="item">Tech Discovery</a></li>
                <li><a href="#" class="item">Trending Styles</a></li>
            </ul>
        </div>
        <div class="section">
            <ul class="list-unstyled">
                <li><a href="#" class="item"><i class="ti-user"></i>&nbsp;&nbsp;Signin</a></li>
                <li><a href="#" class="item"><i class="ti-pencil"></i>&nbsp;&nbsp;Join</a></li>
                <li><a href="#" class="item"><i class="ti-heart"></i>&nbsp;&nbsp;Wishlist</a></li>
                <li><a href="#" class="item"><i class="ti-user"></i>&nbsp;&nbsp;My account</a></li>
                <li><a href="#" class="item"><i class="ti-shopping-cart"></i>&nbsp;&nbsp;My cart</a></li>
            </ul>
        </div>
    </div>
</div>