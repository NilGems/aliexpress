<div class="float-menus-cate-details hidden-md hidden-sm hidden-xs">
    <div class="menu-items-section"  id="cat-show1">

        <div class="row">
            <div class="col-md-9">
                <?php for ($i = 1; $i <= 3; $i++): ?>

                    <div class="col-md-4">
                        <h5>Hot Deals</h5>
                        <ul class="list-unstyled">
                            <li><a href="" class="item">Down Coats</a></li>
                            <li><a href="" class="item">Parkas</a></li>
                            <li><a href="" class="item">Dresses</a></li>
                            <li><a href="" class="item">Blouses &amp; Shirts</a></li>
                            <li><a href="" class="item">T-shirt</a></li>
                            <li><a href="" class="item">Jump suits</a></li>
                        </ul>
                        <h5>Hot Deals</h5>
                        <ul class="list-unstyled">
                            <li><a href="" class="item">Down Coats</a></li>
                            <li><a href="" class="item">Parkas</a></li>
                            <li><a href="" class="item">Dresses</a></li>
                            <li><a href="" class="item">Blouses &amp; Shirts</a></li>
                            <li><a href="" class="item">T-shirt</a></li>
                            <li><a href="" class="item">Jump suits</a></li>
                        </ul>
                        <div class="floating-bottom-img-ads">
                            <a class="hover-footer-img" href="#">
                                <span>Trending Styles</span>
                                <div class="img"><img src="image/small1.png" alt=""/></div>
                            </a>
                        </div>
                    </div>

                <?php endfor; ?>
            </div>
            <div class="col-md-3">
                <div class="col-md-6 mri-zero-padding-left-right">
                     <div class="float-menus-cate-image">
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1LAl9PXXXXXamapXXq6xXFXXXX.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1scayPXXXXXX_XpXXq6xXFXXX4.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1RDX0PXXXXXbuapXXq6xXFXXXl.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1YwWKPXXXXXa0XFXXq6xXFXXXL.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1BCl5PXXXXXbWaXXXq6xXFXXXq.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1vJV_PXXXXXclaXXX760XFXXXe.png" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1SPGfPXXXXXbgapXXq6xXFXXXP.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1vrePPXXXXXXaXFXXq6xXFXXXE.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1lYGEPXXXXXa1XXXXq6xXFXXXX.jpg" alt=""/>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 mri-zero-padding-left-right">
                     <div class="float-menus-cate-image">
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1LAl9PXXXXXamapXXq6xXFXXXX.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1scayPXXXXXX_XpXXq6xXFXXX4.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1RDX0PXXXXXbuapXXq6xXFXXXl.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1YwWKPXXXXXa0XFXXq6xXFXXXL.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1BCl5PXXXXXbWaXXXq6xXFXXXq.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1vJV_PXXXXXclaXXX760XFXXXe.png" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1SPGfPXXXXXbgapXXq6xXFXXXP.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1vrePPXXXXXXaXFXXq6xXFXXXE.jpg" alt=""/>
                        </a>
                        <a href="" class="ui medium bordered image">
                            <img src="image/HTB1lYGEPXXXXXa1XXXXq6xXFXXXX.jpg" alt=""/>
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>