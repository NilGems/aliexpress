<div class="section1">
    <div class="col-lg-3 mri-zero-padding-left-right hidden-md hidden-sm hidden-xs">
        <ul class="side-categorie-list">
            <li><a href="#" data-active="cat-show1"><i class="sprite dress"></i>Women's clothing</a></li>
            <li><a href="#" data-active="cat-show2"><i class="sprite shirt"></i>Men's clothing</a></li>
            <li><a href="#" data-active="cat-show3"><i class="sprite smartphone"></i>Phone &amp; Asseccories</a></li>
            <li><a href="#" data-active="cat-show4"><i class="sprite monitor"></i>Computer &amp; Office</a></li>
            <li><a href="#" data-active="cat-show5"><i class="sprite headphones"></i>Consumer Electronics</a></li>
            <li><a href="#" data-active="cat-show6"><i class="sprite diamond"></i>Jewelry &amp; Watches</a></li>
            <li><a href="#" data-active="cat-show7"><i class="sprite armchair"></i>Home, Garden &amp; Furniture</a></li>
            <li><a href="#" data-active="cat-show8"><i class="sprite bag"></i>Bags &amp; Shoes</a></li>
            <li><a href="#" data-active="cat-show9"><i class="sprite pacifier"></i>Toys, Kids &amp; Baby</a></li>
            <li><a href="#" data-active="cat-show10"><i class="sprite ball"></i>Sports &amp; Outdoor</a></li>
            <li><a href="#" data-active="cat-show11"><i class="sprite lipstick"></i>Health &amp; Beauty</a></li>
            <li><a href="#" data-active="cat-show12"><i class="sprite car"></i>Automobiles &amp; Motorcycles</a></li>
            <li><a href="#" data-active="cat-show13"><i class="sprite jackhammer"></i>Home Improvement</a></li>
        </ul>
    </div>
    <div class="col-lg-9 col-md-12 top-customize-first-section mri-zero-padding-left-right">
        <?php include(dirname(__FILE__).'/section1-float-menus.php');?>
        <div class="col-md-8 mri-zero-padding-left-right">
            <div class="mri-slider-content">
                <div class="owl-carousel" id="main-slider-top">
                    <a href="#">
                        <img src="image/HTB1FD3APXXXXXcJXXXXq6xXFXXXr.jpg" alt=""/>
                    </a>
                    <a href="#">
                        <img src="image/HTB1gso9PXXXXXcnXXXXq6xXFXXXd.jpg" alt=""/>
                    </a>
                    <a href="#">
                        <img src="image/HTB1BDklPXXXXXbPapXX760XFXXXC.png" alt=""/>
                    </a>
                    <a href="#">
                        <img src="image/HTB1fL7hPXXXXXXyaXXXq6xXFXXXV.jpg" alt=""/>
                    </a>
                    <a href="#">
                        <img src="image/HTB15f3FPXXXXXcjXXXXq6xXFXXXz.jpg" alt=""/>
                    </a>
                </div>
                <div class="slide-controller-btn">
                    <div class="left-control"><i class="ti-angle-left"></i></div>
                    <div class="right-control"><i class="ti-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mri-zero-padding-left-right">

            <div class="mri-small-banner">
                <a href="#" class="mri-small-banner-image">
                    <img src="image/HTB1quIRPXXXXXahXVXXq6xXFXXXf.jpg" alt=""/>
                </a>
                <div class="mri-extra-footer">
                    <a href="#"><img src="image/HTB1vbszPXXXXXX6apXXq6xXFXXX0.jpg" alt=""/></a>
                    <a href="#">
                        <span>On sale</span>
                        <span>Jan 25-29</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
</div>