<div class="section2">
    <div class="col-md-12 mri-zero-padding-left-right">
        <a class="big-width-banner" href="#">
            <img src="image/HTB1zBk6PXXXXXcBXXXX760XFXXXP.png" alt=""/>
        </a>
    </div>
    <div class="col-md-12 mri-zero-padding-left-right">
        <div class="column-list-catagories">
            <div class="column-list-contents mri-zero-padding-top-bottom">
                <div class="col-md-2 col-sm-6 col-xs-6"><a href="#"><img src="image/HTB1jMZkPXXXXXbPXFXX760XFXXXl.png" alt=""/><span>Clothing</span></a></div>
                <div class="col-md-2 col-sm-6 col-xs-6"><a href="#"><img src="image/HTB10s7zPXXXXXXPaXXX760XFXXXS.png" alt=""/><span>Phones, Tablets & Accessories</span></a></div>
                <div class="col-md-2 col-sm-6 col-xs-6"><a href="#"><img src="image/HTB1WoMtPXXXXXbyaXXX760XFXXXr.png" alt=""/><span>Electronics</span></a></div>
                <div class="col-md-2 col-sm-6 col-xs-6"><a href="#"><img src="image/HTB15GskPXXXXXbJXFXX760XFXXXW.png" alt=""/><span>Fashion Accessories</span></a></div>
                <div class="col-md-2 col-sm-6 col-xs-6"><a href="#"><img src="image/HTB19HY7PXXXXXa5aXXX760XFXXXq.png" alt=""/><span>Shoes & Bags</span></a></div>
                <div class="col-md-2 col-sm-6 col-xs-6"><a href="#"><img src="image/HTB1AmklPXXXXXb_apXX760XFXXXn.png" alt=""/><span>Mom & Kids</span></a></div>
            </div>
            <div class="column-list-contents mri-zero-padding-top-bottom">
                <div class="col-md-2 col-sm-6 col-xs-6"><a href="#"><img src="image/HTB1WljQPXXXXXcYaFXX760XFXXXV.png" alt=""/><span>Health, Beauty & Hair</span></a></div>
                <div class="col-md-2 col-sm-6 col-xs-6"><a href="#"><img src="image/HTB1GDP2PXXXXXXeapXX760XFXXXn.png" alt=""/><span>Home & Garden</span></a></div>
                <div class="col-md-2 col-sm-6 col-xs-6"><a href="#"><img src="image/HTB1G0n8PXXXXXcFXVXX760XFXXXP.png" alt=""/><span>Sports $ Outdoors</span></a></div>
                <div class="col-md-2 col-sm-6 col-xs-6"><a href="#"><img src="image/HTB1RsY0PXXXXXaqapXX760XFXXXQ.png" alt=""/><span>Home Improvement & Security</span></a></div>
                <div class="col-md-2 col-sm-6 col-xs-6"><a href="#"><img src="image/HTB1dRQhPXXXXXXAXVXX760XFXXXT.png" alt=""/><span>Automobiles & Motorcycles</span></a></div>
                <div class="col-md-2 col-sm-6 col-xs-6"><a href="#"><img src="image/HTB1QVIfPXXXXXbAXVXXq6xXFXXXZ.jpg" alt=""/></a></div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="clearfix"></div>
</div>