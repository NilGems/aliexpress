<div class="section3 full-width-sec">
    <div class="col-md-3 mri-zero-padding-left-right">
        <div class="title-section">
            <div>
                <a href="#"><h2 class="heading">SUPER DEALS</h2></a>
                <div class="coundown time-coudown-counter" data-target-date="2017/02/03 16:38:00">
                    <div>Deal ends in:</div>
                    <div class="timer-section">22:02:09</div>
                </div>
                <a class="view" href="#">View <span>358</span> items</a>
            </div>
        </div>
    </div>
    <div class="col-md-9 mri-zero-padding-left-right">
        <div class="col-md-3 mri-zero-padding-left-right">
            <a class="deal-offer" href="#">
                <div class="deal-offer-banner"><img src="image/HTB1psfjPXXXXXXbXXXXq6xXFXXXL.jpg_220x220.jpg" alt=""/></div>
                <div class="deal-offer-details">
                    <div class="deal-offer-price"><span>US $44.16</span><span>US $92.00</span></div>
                    <div class="deal-offer-off"><span>52% off</span></div>
                </div>
            </a>
        </div>
        <div class="col-md-3 mri-zero-padding-left-right">
            <a class="deal-offer" href="#">
                <div class="deal-offer-banner"><img src="image/HTB11jBkPXXXXXa_XVXXq6xXFXXXE.jpg_220x220.jpg" alt=""/></div>
                <div class="deal-offer-details">
                    <div class="deal-offer-price"><span>US $44.16</span><span>US $92.00</span></div>
                    <div class="deal-offer-off"><span>52% off</span></div>
                </div>
            </a>
        </div>
        <div class="col-md-3 mri-zero-padding-left-right">
            <a class="deal-offer" href="#">
                <div class="deal-offer-banner"><img src="image/HTB1MkYxLXXXXXcyXFXXq6xXFXXXI.jpg_220x220.jpg" alt=""/></div>
                <div class="deal-offer-details">
                    <div class="deal-offer-price"><span>US $44.16</span><span>US $92.00</span></div>
                    <div class="deal-offer-off"><span>52% off</span></div>
                </div>
            </a>
        </div>
        <div class="col-md-3 mri-zero-padding-left-right">
            <a class="deal-offer" href="#">
                <div class="deal-offer-banner"><img src="image/HTB1XX8LKXXXXXXjXpXXq6xXFXXXe.jpg_220x220.jpg" alt=""/></div>
                <div class="deal-offer-details">
                    <div class="deal-offer-price"><span>US $44.16</span><span>US $92.00</span></div>
                    <div class="deal-offer-off"><span>52% off</span></div>
                </div>
            </a>
        </div>
    </div>
    <div class="clearfix"></div>
</div>