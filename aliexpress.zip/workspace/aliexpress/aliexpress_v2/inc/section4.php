<div class="section4 full-width-sec">
    <div class="col-md-3 mri-zero-padding-left-right">
        <div class="title-section">
            <div>
                <a href="#"><h2 class="ui heading">TECH DISCOVERY</h2></a>
                <div class="shop-now-btn">
                    <button class="btn btn-warning">SHOP NOW</button>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-9">
        <div class="section-slider">
            <div class="slider">
                <div class="slide-controller previtem"><span><i class="ti-angle-left"></i></span></div>
                <div class="owl-carousel carousel-holder">
                    <a class="deal-offer" href="#">
                        <div class="deal-offer-banner"><img src="image/HTB1psfjPXXXXXXbXXXXq6xXFXXXL.jpg_220x220.jpg" alt=""/></div>
                        <div class="deal-offer-details">
                            <div class="deal-offer-price seperate"><span>US $44.16</span><span>US $92.00</span></div>
                        </div>
                    </a>
                    <a class="deal-offer" href="#">
                        <div class="deal-offer-banner"><img src="image/HTB11jBkPXXXXXa_XVXXq6xXFXXXE.jpg_220x220.jpg" alt=""/></div>
                        <div class="deal-offer-details">
                            <div class="deal-offer-price seperate"><span>US $44.16</span><span>US $92.00</span></div>
                        </div>
                    </a>
                    <a class="deal-offer" href="#">
                        <div class="deal-offer-banner"><img src="image/HTB1MkYxLXXXXXcyXFXXq6xXFXXXI.jpg_220x220.jpg" alt=""/></div>
                        <div class="deal-offer-details">
                            <div class="deal-offer-price seperate"><span>US $44.16</span><span>US $92.00</span></div>
                        </div>
                    </a>
                    <a class="deal-offer" href="#">
                        <div class="deal-offer-banner"><img src="image/HTB1XX8LKXXXXXXjXpXXq6xXFXXXe.jpg_220x220.jpg" alt=""/></div>
                        <div class="deal-offer-details">
                            <div class="deal-offer-price seperate"><span>US $44.16</span><span>US $92.00</span></div>
                        </div>
                    </a>
                    <a class="deal-offer" href="#">
                        <div class="deal-offer-banner"><img src="image/HTB1psfjPXXXXXXbXXXXq6xXFXXXL.jpg_220x220.jpg" alt=""/></div>
                        <div class="deal-offer-details">
                            <div class="deal-offer-price seperate"><span>US $44.16</span><span>US $92.00</span></div>
                        </div>
                    </a>
                </div>
                <div class="slide-controller nextitem"><span><i class="ti-angle-right"></i></span></div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
</div>