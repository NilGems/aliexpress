<div class="section5 catagory-wide sky" id="cat-automobilesandmotorcycles">
    <div class="col-md-3 mri-zero-padding-left-right">
        <a href="#" class="title">
            <span>AUTOMOBILES &amp; MOTORCYCLES</span>
            <span><i class="ti-angle-right"></i></span>
        </a>
        <ul class="links">
            <li class="color"><a href="#">Casual Dresses</a></li>
            <li><a href="#">Cardigans</a></li>
            <li class="color"><a href="#">Autumn Dresses</a></li>
            <li class="color"><a href="#">Coat &amp; Jackets</a></li>
            <li class="color"><a href="#">Sweaters</a></li>
            <li><a href="#">Blouses &amp; Shirts</a></li>
            <li><a href="#">T-Shirts</a></li>
            <li class="color"><a href="#">Sunglasses</a></li>
            <li><a href="#">Intimates&amp;Sleepwear</a></li>
            <li><a href="#">Scarves</a></li>
            <li><a href="#">Hair Accessories</a></li>
        </ul>
    </div>
    <div class="col-md-4 mri-zero-padding-left-right">
        <div class="big-slider-contents">
            <div class="owl-carousel">
                <a href="#">
                    <img src="image/HTB1sfcOPXXXXXcOXFXXq6xXFXXXV.jpg"/>
                    <div class="text-zone">
                        <div class="heading-section">LOOKING GORGEOUS</div>
                        <div class="cmd-txt">Simplee official Store</div>
                    </div>
                </a>
                <a href="#">
                    <img src="image/HTB1ZIaKOVXXXXauapXXq6xXFXXXD.jpg"/>
                    <div class="text-zone">
                        <div class="heading-section">LOOKING GORGEOUS</div>
                        <div class="cmd-txt">Simplee official Store</div>
                    </div>
                </a>
            </div>
            <div class="slide-controller-btn">
                <div class="left-control"><i class="ti-angle-left"></i></div>
                <div class="right-control"><i class="ti-angle-right"></i></div>
            </div>
        </div>
    </div>
    <div class="col-md-5 mri-zero-padding-left-right">
        <div>
            <div class="medium col-md-8 mri-zero-padding-left-right">
                <a href="#">
                    <img src="image/HTB1wppgPpXXXXawXpXXq6xXFXXXh.jpg"/>
                </a>
            </div>
            <div class="small col-md-4 col-sm-6 col-xs-6  mri-zero-padding-left-right">
                <a href="#">
                    <div class="title-head">
                        <span>Bosideng</span>
                        <span>Who's queen</span>
                    </div>
                    <img src='image/HTB1mfKuOFXXXXatXVXXq6xXFXXXd.jpg'/>
                </a>
            </div>
            <div class="small col-md-4 col-sm-6 col-xs-6  mri-zero-padding-left-right">
                <a href="#">
                    <div class="title-head">
                        <span>Downn Coat</span>
                        <span>2016 Collection</span>
                    </div>
                    <img src='image/HTB150_ZMVXXXXbrapXXq6xXFXXXj.jpg'/>
                </a>
            </div>
            <div class="small col-md-4 col-sm-6 col-xs-6  mri-zero-padding-left-right">
                <a href="#">
                    <div class="title-head">
                        <span>Coats &amp; Jacket</span>
                        <span>New Arrivals</span>
                    </div>
                    <img src='image/HTB17DC3KVXXXXc7XpXXq6xXFXXX9.jpg'/>
                </a>
            </div>
            <div class="small col-md-4 col-sm-6 col-xs-6  mri-zero-padding-left-right">
                <a href="#">
                    <div class="title-head">
                        <span>Accessories</span>
                        <span>For her</span>
                    </div>
                    <img src='image/HTB1O5ktPXXXXXaDaXXXq6xXFXXXI.jpg'/>
                </a>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
</div>