<div class="container">
        <div class="section6">
            <div class="col-md-12 mri-zero-padding-left-right">
                <div class="pull-left text-left"><h4>Recommendations for you</h4></div>
                <div class="pull-right text-right">
                    <button class="btn btn-warning"><i class="ti-reload"></i>&nbsp;&nbsp;Try your luck</button>
                </div>
            </div>
            <div class="row">
                <?php for($i=1;$i<=7;$i++):?>
                    <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12">
                        <div class="card">
                            <a href="" class="image">
                                <img class="img-rounded" src="image/1PCS-Knee-brace-Mcdavid-Honeycomb-kneepad-Famousbrand-knee-pad-elbow-support-Basketball-Leg-Sleeve-Breathable-Sport.jpg_250x250">
                            </a>
                            <div class="content">
                                <div class="pull-left ct">
                                    <h3 class="header">US $ 4.33</h3>
                                    <div class="meta">
                                        <a><s>US $ 13.00</s></a>
                                    </div>
                                </div>
                                <div class="pull-right ct sold">1112 Sold</div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                <?php endfor;?>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>