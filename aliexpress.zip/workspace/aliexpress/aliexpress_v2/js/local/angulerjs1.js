(function () {
    var app = angular.module('nilalixpress', []);
    app.controller('header', ['$scope', function ($scope) {
            $scope.searchbarcats = [
                {name: 'All Categories', value: 0},
                {name: "Women's Clothing & Accessories", value: 1},
                {name: "Men's Clothing & Accessories", value: 1},
                {name: "Phones & Telecommunications", value: 1},
                {name: "Computer & Office", value: 1},
                {name: "Consumer Electronics", value: 1},
                {name: "Jewelry & Accessories", value: 1},
                {name: "Home & Garden", value: 1},
                {name: "Luggage & Bags", value: 1},
                {name: "Shoes", value: 1},
                {name: "Mother & Kids", value: 1},
                {name: "Sports & Entertainment", value: 1},
                {name: "Beauty & Health", value: 1},
                {name: "Watches", value: 1},
                {name: "Toys & Hobbies", value: 1},
                {name: "Weddings & Events", value: 1},
                {name: "Novelty & Special Use", value: 1},
                {name: "Automobiles & Motorcycles", value: 1},
                {name: "Lights & Lighting", value: 1},
                {name: "Furniture", value: 1},
                {name: "Electronic Components & Supplies", value: 1},
                {name: "Office & School Supplies", value: 1},
                {name: "Home Improvement", value: 1},
                {name: "Food", value: 1},
                {name: "Security & Protection", value: 1},
                {name: "In All Categories", value: 1}
            ];
            $scope.searchengine_on = function () {
                var $$$ = jQuery;
                $$$('.navigation-bar>.header-waper>div>.search-box .search-results').show();
            };
            $scope.searchengine_off = function () {
                var $$$ = jQuery;
                $$$('.navigation-bar>.header-waper>div>.search-box .search-results').hide();
            };
        }]);
})();

