(function ($) {
    $(document).ready(function () {
        /****************SLIDERS START**********************/
        $('#main-slider-top').owlCarousel({singleItem:true,autoPlay:true,stopOnHover:true});
        $('.mri-slider-content .slide-controller-btn>div.left-control').on('click',function(event){
           event.preventDefault();
           var mainslider = $('#main-slider-top').data('owlCarousel');
           mainslider.prev();
        });
        $('.mri-slider-content .slide-controller-btn>div.right-control').on('click',function(event){
           event.preventDefault();
           var mainslider = $('#main-slider-top').data('owlCarousel');
           mainslider.next();
        });
        $('.full-width-sec .section-slider .owl-carousel').owlCarousel({items:4,itemsMobile:[479,1],pagination:false});
        $('.full-width-sec .section-slider>.slider>.slide-controller').on('click',function(event){
            event.preventDefault();
            var owlCarousel = $(this).closest('.slider').find('.carousel-holder').data('owlCarousel');
            if($(this).hasClass('previtem')){
                owlCarousel.prev();
            }else if($(this).hasClass('nextitem')){
                owlCarousel.next();
            }
        });
        $('.catagory-wide .big-slider-contents .owl-carousel').owlCarousel({singleItem:true,autoPlay:true,stopOnHover:true});
        $('.catagory-wide .big-slider-contents .slide-controller-btn>div').on('click',function(event){
            event.preventDefault();
            var owlCarousel = $(this).closest('.big-slider-contents').find('.owl-carousel').data('owlCarousel');
            if($(this).hasClass('left-control')){
                owlCarousel.prev();
            }else if($(this).hasClass('right-control')){
                owlCarousel.next();
            }
        });
        /****************SLIDERS END**********************/
        var top_cat_details_activator = null;
        $('.section1 .side-categorie-list>li>a[data-active]').on('mouseenter',function(){
            var target = $(this).attr('data-active'),sec1 = $(this).closest('.section1');
            if(typeof sec1.attr('data-actives')!=='string'){
                top_cat_details_activator = setTimeout(function(){ sec1.attr('data-actives',target);},700);
            }else{
                sec1.attr('data-actives',target);
            }
        }).on('mouseleave',function(){
            clearTimeout(top_cat_details_activator);
            var target = $(this).attr('data-active'), 
                sec1 = $(this).closest('.section1'),
                ac=typeof sec1.attr('data-actives')!=='string'?null:sec1.attr('data-actives');
                if(ac && target === sec1){
                    sec1.removeAttr('data-actives');
                }
        });
        $('.section1').on('mouseleave',function(){
           if(typeof $(this).attr('data-actives')==='string'){
               $(this).removeAttr('data-actives');
           } 
        });
        $('.time-coudown-counter[data-target-date]').each(function (index, element) {
            var target = $(element).attr('data-target-date');
            $(element).countdown(target, function (event) {
                var totalHours = event.offset.totalDays * 24 + event.offset.hours;
                $(this).find('.timer-section').html(event.strftime(totalHours + '<span>:</span>%M<span>:</span>%S'));
            });
        });
        $(window).on('scroll',function(){
            var fixing_content = $('.sticky-cats .left-side-section-scrollfire'),
            ref = $('.sticky-cats'),
            ref_last = ref.find('.catagory-wide').eq(ref.find('.catagory-wide').length-1).offset().top+ref.find('.catagory-wide').eq(ref.find('.catagory-wide').length-1).height(),
            window_foot = $(window).scrollTop()+$(window).height();
            if(!fixing_content.hasClass('fixed') && $(window).scrollTop() >= ref.offset().top && ref_last > $(window).scrollTop()){
                fixing_content.addClass('fixed');
            }else if(fixing_content.hasClass('fixed') && ref.offset().top > $(window).scrollTop()){
                fixing_content.removeClass('fixed');
            }else if(fixing_content.hasClass('fixed') && $(window).scrollTop() > ref_last){
                fixing_content.removeClass('fixed');
            }
        });
        $('.catagory-wide').each(function (index, element) {
            var waypoint = $(element).waypoint({
                handler: function () {
                    var ptarget = $('.left-side-section-scrollfire>a.active');
                    var target = $('.left-side-section-scrollfire>a[data-target="#'+$(element).attr('id')+'"]');
                    ptarget.removeClass('active');
                    target.addClass('active');
                }
            });
        });
        $('.left-side-section-scrollfire>a').on('click',function(event){
           event.preventDefault();
           var scroll = $($(this).attr('data-target')).offset().top,
           wsa=$(window).scrollTop();
           if(scroll>wsa){
               scroll+=25;
           }else if(wsa>scroll){
               scroll-=25;
           }
            $('body').animate({
                scrollTop: scroll
            }, 1000);
            return false;
        });
        $('.navigation-bar>.header-waper>div>.site-logo>.mobile-option-comming').click(function(){
            $('html').addClass('not-scroll');
            $('.mobile-site-navigation-bar').show();
            $('.mobile-site-navigation-bar>.containts').animate({right:0});
        });
        $('.mobile-site-navigation-bar>.containts>.heading-mob').click(function(event){
            event.preventDefault();
            $('.mobile-site-navigation-bar>.containts').animate({right:'-100%'},{
                complete:function(){
                    $('html').removeClass('not-scroll');
                    $('.mobile-site-navigation-bar').removeAttr('style');
                }
            });
        });
        $('.hovereffect-menu.clickopoen .hovereffect-mn-btn').on('click',function(event){
            event.preventDefault();
            if(!$(this).closest('.hovereffect-menu.clickopoen').find('.menu-options').is(':visible')){
                $(this).closest('.hovereffect-menu.clickopoen').find('.menu-options').show();
            }
        });
        $('.hovereffect-menu.clickopoen .menu-options .hovereffect-close').on('click',function(){
            $(this).closest('.menu-options').hide();
        });
        $(document).on('mouseup',function(event){
           var tr = $(event.target);
           if($('.hovereffect-menu.clickopoen').is(":visible") && !tr.is($('.hovereffect-menu.clickopoen')) && !tr.is($('.hovereffect-menu.clickopoen *'))){
               $('.hovereffect-menu.clickopoen').find('.menu-options').hide();
           }
        });
        $(window).on('scroll',function(){
            var wa = $(window).scrollTop(),target = $('.fixed-items-all');
            if(wa>100 && !target.hasClass('scrollon')){
                target.addClass('scrollon');
            }
            else if(wa<=100 && target.hasClass('scrollon')){
                target.removeClass('scrollon');
            }
        });
        $('.fixed-items-all>.digkiop-uio>.vartical2>.item.scrollController').on('click',function(event){
            event.preventDefault();
            $('body').animate({
                scrollTop:0
            }, 500);
        });
        $('.fixed-items-all>.digkiop-uio>.vartical2>.item.toggle-vartical1-off').on('click',function(event){
            event.preventDefault();
            var target = $('.fixed-items-all');
            if(target.hasClass('vartical1-off')){target.removeClass('vartical1-off');}
            if(!target.hasClass('vartical1-on')){target.addClass('vartical1-on');}
        });
        $('.fixed-items-all>.digkiop-uio>.vartical2>.item.toggle-vartical1-on').on('click',function(event){
            event.preventDefault();
            var target = $('.fixed-items-all');
            if(target.hasClass('vartical1-on')){target.removeClass('vartical1-on');}
            if(!target.hasClass('vartical1-off')){target.addClass('vartical1-off');}
        });
    });
})(jQuery);